package com.navAlert.model

data class AlertEvent(
    val type: AlertType,
    val title: String,
    val message: String,
    val distanceMeters: Int,
    val latitude: Double,
    val longitude: Double,
    val speedLimit: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class AlertType {
        SPEED_CAMERA_APPROACHING,   // avviso a distanza configurabile
        SPEED_CAMERA_NEAR,          // avviso ravvicinato (50m)
        POI_APPROACHING,
        OVER_SPEED_LIMIT            // velocità attuale supera il limite
    }
}

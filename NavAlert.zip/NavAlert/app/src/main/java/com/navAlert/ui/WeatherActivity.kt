package com.navAlert.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.navAlert.R
import com.navAlert.databinding.ActivityWeatherBinding
import com.navAlert.model.WeatherData
import com.navAlert.model.WeatherForecast
import com.navAlert.service.NavigationService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class WeatherActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWeatherBinding
    private var navigationService: NavigationService? = null
    private var serviceBound = false
    private lateinit var forecastAdapter: ForecastAdapter

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as NavigationService.LocalBinder
            navigationService = binder.getService()
            serviceBound = true
            // Mostra meteo corrente dalla cache
            navigationService?.currentWeather?.let { showCurrentWeather(it) }
            showForecast(navigationService?.weatherManager?.cachedForecast ?: emptyList())
            // Se non c'è nulla, avvia fetch manuale
            if (navigationService?.currentWeather == null) {
                navigationService?.lastLocation?.let { loc ->
                    lifecycleScope.launch {
                        val weather = navigationService?.weatherManager?.fetchCurrentWeather(loc.latitude, loc.longitude)
                        weather?.let { withContext(Dispatchers.Main) { showCurrentWeather(it) } }
                        val forecast = navigationService?.weatherManager?.fetchForecast(loc.latitude, loc.longitude) ?: emptyList()
                        withContext(Dispatchers.Main) { showForecast(forecast) }
                    }
                }
            }
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            navigationService = null; serviceBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWeatherBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Meteo"

        forecastAdapter = ForecastAdapter(emptyList())
        binding.recyclerForecast.layoutManager = LinearLayoutManager(this)
        binding.recyclerForecast.adapter = forecastAdapter

        binding.btnRefresh.setOnClickListener { refreshWeather() }

        bindService(Intent(this, NavigationService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun showCurrentWeather(weather: WeatherData) {
        binding.tvCurrentEmoji.text = weather.emoji
        binding.tvCurrentTemp.text = "${weather.tempCelsius.toInt()}°C"
        binding.tvFeelsLike.text = "Percepita ${weather.feelsLikeCelsius.toInt()}°C"
        binding.tvCurrentDesc.text = weather.conditionDescription.replaceFirstChar { it.uppercase() }
        binding.tvWind.text = "💨 ${weather.windSpeedKmh.toInt()} km/h ${weather.windDirection}"
        binding.tvWindGust.text = if (weather.windGustKmh > weather.windSpeedKmh + 5)
            "Raffiche fino a ${weather.windGustKmh.toInt()} km/h" else ""
        binding.tvHumidity.text = "💧 Umidità: ${weather.humidity}%"
        binding.tvPressure.text = "🔵 Pressione: ${weather.pressureHPa} hPa"
        binding.tvVisibility.text = "👁 Visibilità: ${
            if (weather.visibilityMeters >= 10000) ">10 km"
            else "${weather.visibilityMeters / 1000.0} km"
        }"
        binding.tvCity.text = "📍 ${weather.cityName}"

        val lastUpdate = SimpleDateFormat("HH:mm", Locale.ITALY).format(Date(weather.timestamp))
        binding.tvLastUpdate.text = "Aggiornato: $lastUpdate"

        // Precipitazioni
        val precipStr = buildString {
            if (weather.rain1hMm > 0) append("🌧 Pioggia: ${weather.rain1hMm} mm/h  ")
            if (weather.snow1hMm > 0) append("❄ Neve: ${weather.snow1hMm} mm/h")
        }
        binding.tvPrecip.text = precipStr
        binding.tvPrecip.visibility = if (precipStr.isNotBlank()) View.VISIBLE else View.GONE

        // Alert condizioni pericolose
        if (weather.requiresAlert) {
            binding.cardWarning.visibility = View.VISIBLE
            binding.tvWarningMessage.text = "⚠️ ${weather.alertMessage}"
        } else {
            binding.cardWarning.visibility = View.GONE
        }
    }

    private fun showForecast(forecasts: List<WeatherForecast>) {
        forecastAdapter.update(forecasts)
        binding.tvForecastTitle.visibility = if (forecasts.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun refreshWeather() {
        val loc = navigationService?.lastLocation
        if (loc == null) {
            binding.tvLastUpdate.text = "GPS non disponibile - avvia la navigazione"
            return
        }
        binding.btnRefresh.isEnabled = false
        binding.tvLastUpdate.text = "Aggiornamento..."
        lifecycleScope.launch {
            val weather = navigationService?.weatherManager?.fetchCurrentWeather(loc.latitude, loc.longitude)
            val forecast = navigationService?.weatherManager?.fetchForecast(loc.latitude, loc.longitude) ?: emptyList()
            withContext(Dispatchers.Main) {
                weather?.let { showCurrentWeather(it) }
                showForecast(forecast)
                binding.btnRefresh.isEnabled = true
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }

    override fun onDestroy() {
        if (serviceBound) { unbindService(serviceConnection); serviceBound = false }
        super.onDestroy()
    }
}

class ForecastAdapter(private var items: List<WeatherForecast>) :
    RecyclerView.Adapter<ForecastAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvTime: TextView = view.findViewById(R.id.tvForecastTime)
        val tvDate: TextView = view.findViewById(R.id.tvForecastDate)
        val tvEmoji: TextView = view.findViewById(R.id.tvForecastEmoji)
        val tvTemp: TextView = view.findViewById(R.id.tvForecastTemp)
        val tvWind: TextView = view.findViewById(R.id.tvForecastWind)
        val tvPop: TextView = view.findViewById(R.id.tvForecastPop)
        val tvDesc: TextView = view.findViewById(R.id.tvForecastDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_forecast, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val f = items[position]
        holder.tvTime.text = f.timeLabel
        holder.tvDate.text = f.dateLabel
        holder.tvEmoji.text = f.emoji
        holder.tvTemp.text = "${f.tempCelsius.toInt()}°C"
        holder.tvWind.text = "💨${f.windSpeedKmh.toInt()}"
        holder.tvPop.text = if (f.pop > 0.1f) "☔${(f.pop * 100).toInt()}%" else ""
        holder.tvDesc.text = f.conditionDescription
    }

    override fun getItemCount() = items.size

    fun update(newItems: List<WeatherForecast>) {
        items = newItems
        notifyDataSetChanged()
    }
}

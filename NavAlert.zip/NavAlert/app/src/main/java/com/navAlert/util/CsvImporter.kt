package com.navAlert.util

import android.content.Context
import android.net.Uri
import com.navAlert.db.DatabaseHelper
import com.navAlert.model.PointOfInterest
import com.navAlert.model.SpeedCamera
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

object CsvImporter {

    data class ImportResult(
        val fileName: String,
        val imported: Int,
        val skipped: Int,
        val errors: Int,
        val type: ImportType
    )

    enum class ImportType { SPEED_CAMERA, POI, AUTO_DETECT }

    /** Importa da URI (file picker) */
    suspend fun importFromUri(
        context: Context,
        uri: Uri,
        dbHelper: DatabaseHelper,
        forceType: ImportType = ImportType.AUTO_DETECT,
        replaceExisting: Boolean = false
    ): ImportResult = withContext(Dispatchers.IO) {

        val fileName = getFileName(context, uri) ?: "unknown.csv"
        if (replaceExisting) dbHelper.deleteCamerasBySource(fileName)

        val cameras = mutableListOf<SpeedCamera>()
        val pois = mutableListOf<PointOfInterest>()
        var skipped = 0; var errors = 0

        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            BufferedReader(InputStreamReader(inputStream)).forEachLine { line ->
                val trimmed = line.trim()
                if (trimmed.isEmpty() || trimmed.startsWith("#") || trimmed.startsWith(";")) {
                    skipped++; return@forEachLine
                }
                try {
                    when (val parsed = parseLine(trimmed, fileName, forceType)) {
                        is ParsedEntry.Camera -> cameras.add(parsed.camera)
                        is ParsedEntry.Poi -> pois.add(parsed.poi)
                        null -> skipped++
                    }
                } catch (e: Exception) { errors++ }
            }
        }

        if (cameras.isNotEmpty()) dbHelper.insertCamerasBatch(cameras)
        if (pois.isNotEmpty()) dbHelper.insertPoisBatch(pois)

        ImportResult(
            fileName,
            cameras.size + pois.size,
            skipped, errors,
            if (cameras.isNotEmpty()) ImportType.SPEED_CAMERA else ImportType.POI
        )
    }

    /** Importa tutti i CSV dagli assets al primo avvio */
    suspend fun importFromAssets(
        context: Context,
        dbHelper: DatabaseHelper,
        assetFolder: String = "autovelox"
    ): List<ImportResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<ImportResult>()
        try {
            val files = context.assets.list(assetFolder) ?: return@withContext results
            files.filter { it.endsWith(".csv", ignoreCase = true) }.forEach { fileName ->
                val cameras = mutableListOf<SpeedCamera>()
                val pois = mutableListOf<PointOfInterest>()
                var skipped = 0; var errors = 0

                context.assets.open("$assetFolder/$fileName").use { inputStream ->
                    BufferedReader(InputStreamReader(inputStream)).forEachLine { line ->
                        val trimmed = line.trim()
                        if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                            skipped++; return@forEachLine
                        }
                        try {
                            when (val parsed = parseLine(trimmed, fileName, ImportType.AUTO_DETECT)) {
                                is ParsedEntry.Camera -> cameras.add(parsed.camera)
                                is ParsedEntry.Poi -> pois.add(parsed.poi)
                                null -> skipped++
                            }
                        } catch (e: Exception) { errors++ }
                    }
                }

                if (cameras.isNotEmpty()) dbHelper.insertCamerasBatch(cameras)
                if (pois.isNotEmpty()) dbHelper.insertPoisBatch(pois)

                results.add(ImportResult(
                    fileName,
                    cameras.size + pois.size,
                    skipped, errors,
                    if (cameras.isNotEmpty()) ImportType.SPEED_CAMERA else ImportType.POI
                ))
            }
        } catch (e: Exception) { /* assets non trovati */ }
        results
    }

    // ---- Parsing ----

    private sealed class ParsedEntry {
        data class Camera(val camera: SpeedCamera) : ParsedEntry()
        data class Poi(val poi: PointOfInterest) : ParsedEntry()
    }

    private fun parseLine(line: String, fileName: String, forceType: ImportType): ParsedEntry? {
        val parts = line.split(",")
        if (parts.size < 3) return null

        val lon = parts[0].trim().toDoubleOrNull() ?: return null
        val lat = parts[1].trim().toDoubleOrNull() ?: return null
        val rawDesc = parts.drop(2).joinToString(",").trim()

        // Determina la categoria dal nome del file (più affidabile)
        val categoryFromFile = SpeedCamera.CameraCategory.fromFileName(fileName)

        // Estrai velocità se presente (@XX)
        val atIndex = rawDesc.lastIndexOf('@')
        val description: String
        val speedLimit: Int

        if (atIndex >= 0) {
            description = rawDesc.substring(0, atIndex).trim()
            speedLimit = rawDesc.substring(atIndex + 1).trim().toIntOrNull() ?: 0
        } else {
            description = rawDesc
            speedLimit = 0
        }

        // Corsie Preferenziali e Sorpassometri -> trattati come POI (no enforcement)
        if (forceType == ImportType.POI ||
            (categoryFromFile == SpeedCamera.CameraCategory.PREFERRED_LANE ||
             categoryFromFile == SpeedCamera.CameraCategory.SORPASSOMETRO) &&
            forceType != ImportType.SPEED_CAMERA) {
            val poiCat = when (categoryFromFile) {
                SpeedCamera.CameraCategory.PREFERRED_LANE -> PointOfInterest.PoiCategory.PREFERRED_LANE
                SpeedCamera.CameraCategory.SORPASSOMETRO -> PointOfInterest.PoiCategory.DANGER
                SpeedCamera.CameraCategory.BLACK_POINT -> PointOfInterest.PoiCategory.DANGER
                else -> PointOfInterest.PoiCategory.fromDescription(description)
            }
            return ParsedEntry.Poi(PointOfInterest(
                longitude = lon, latitude = lat,
                name = description,
                category = poiCat,
                sourceFile = fileName
            ))
        }

        val category = categoryFromFile
            ?: if (atIndex >= 0) SpeedCamera.CameraCategory.fromDescription(rawDesc)
               else if (forceType == ImportType.SPEED_CAMERA) SpeedCamera.CameraCategory.fromDescription(description)
               else return ParsedEntry.Poi(PointOfInterest(
                    longitude = lon, latitude = lat,
                    name = description,
                    category = PointOfInterest.PoiCategory.fromDescription(description)
                ))

        return ParsedEntry.Camera(SpeedCamera(
            longitude = lon, latitude = lat,
            description = if (description.isNotEmpty()) description else category.label,
            speedLimit = speedLimit,
            category = category,
            sourceFile = fileName
        ))
    }

    private fun getFileName(context: Context, uri: Uri): String? =
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) else null
            } else null
        } ?: uri.lastPathSegment
}

package com.navAlert.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.location.Location
import android.os.Binder
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.preference.PreferenceManager
import com.google.android.gms.location.*
import com.navAlert.R
import com.navAlert.db.DatabaseHelper
import com.navAlert.model.AlertEvent
import com.navAlert.model.PointOfInterest
import com.navAlert.model.SpeedCamera
import com.navAlert.model.WeatherData
import com.navAlert.ui.MainActivity
import com.navAlert.util.AlertManager
import com.navAlert.util.WeatherManager
import kotlinx.coroutines.*

class NavigationService : Service() {

    companion object {
        const val CHANNEL_ID = "navAlert_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "START_NAV"
        const val ACTION_STOP = "STOP_NAV"
    }

    inner class LocalBinder : Binder() {
        fun getService(): NavigationService = this@NavigationService
    }

    private val binder = LocalBinder()
    private var isRunning = false

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var alertManager: AlertManager
    lateinit var weatherManager: WeatherManager
        private set

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val prefs get() = PreferenceManager.getDefaultSharedPreferences(this)

    var lastLocation: Location? = null
    var currentSpeedKmh: Float = 0f
    var currentWeather: WeatherData? = null

    var onLocationUpdate: ((Location, Float) -> Unit)? = null
    var onAlert: ((AlertEvent) -> Unit)? = null
    var onWeatherUpdate: ((WeatherData) -> Unit)? = null

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        dbHelper = DatabaseHelper(this)
        alertManager = AlertManager(this)
        weatherManager = WeatherManager(this).apply {
            onWeatherUpdate = { weather ->
                currentWeather = weather
                this@NavigationService.onWeatherUpdate?.invoke(weather)
                updateNotification(buildNotificationText())
            }
            onWeatherAlert = { weather ->
                if (prefs.getBoolean("weather_alerts_enabled", true)) {
                    alertManager.speakWeatherAlert(weather)
                }
            }
        }
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startNavigation()
            ACTION_STOP -> stopNavigation()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder = binder

    fun startNavigation() {
        if (isRunning) return
        isRunning = true
        startForeground(NOTIFICATION_ID, buildNotification(buildNotificationText()))
        startLocationUpdates()
    }

    fun stopNavigation() {
        isRunning = false
        fusedLocationClient.removeLocationUpdates(locationCallback)
        alertManager.clearCooldowns()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    fun isNavigating() = isRunning

    private fun startLocationUpdates() {
        val intervalMs = prefs.getString("gps_interval", "2000")?.toLongOrNull() ?: 2000L
        val minDistance = prefs.getString("gps_min_distance", "10")?.toFloatOrNull() ?: 10f

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMs)
            .setMinUpdateDistanceMeters(minDistance)
            .setWaitForAccurateLocation(false)
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { handleLocationUpdate(it) }
            }
        }

        try {
            fusedLocationClient.requestLocationUpdates(
                request, locationCallback, Looper.getMainLooper()
            )
        } catch (e: SecurityException) {
            stopNavigation()
        }
    }

    private fun handleLocationUpdate(location: Location) {
        lastLocation = location
        currentSpeedKmh = if (location.hasSpeed()) location.speed * 3.6f else currentSpeedKmh

        onLocationUpdate?.invoke(location, currentSpeedKmh)

        serviceScope.launch {
            checkNearbyAlerts(location)
            weatherManager.updateIfNeeded(location.latitude, location.longitude)
        }

        updateNotification(buildNotificationText())
    }

    private suspend fun checkNearbyAlerts(location: Location) {
        val searchRadiusMeters = prefs.getString("search_radius", "500")?.toDoubleOrNull() ?: 500.0
        val alertDistanceMeters = prefs.getString("alert_distance", "300")?.toIntOrNull() ?: 300
        val nearAlertDistanceMeters = 80

        if (prefs.getBoolean("alerts_cameras_enabled", true)) {
            val cameras = dbHelper.getCamerasInBoundingBox(
                location.latitude, location.longitude, searchRadiusMeters, true
            )
            cameras.forEach { camera ->
                if (!isCategoryAlertEnabled(camera.category)) return@forEach
                val cameraLocation = Location("camera").apply {
                    latitude = camera.latitude; longitude = camera.longitude
                }
                val distanceM = location.distanceTo(cameraLocation).toInt()

                // Dossi e dissuasori usano una distanza di avviso ridotta configurabile
                val effectiveAlertDistance = when (camera.category) {
                    SpeedCamera.CameraCategory.SPEED_BUMP,
                    SpeedCamera.CameraCategory.DISSUASORE ->
                        prefs.getString("alert_distance_bumps", "150")?.toIntOrNull() ?: 150
                    SpeedCamera.CameraCategory.BLACK_POINT,
                    SpeedCamera.CameraCategory.SORPASSOMETRO ->
                        prefs.getString("alert_distance", "300")?.toIntOrNull() ?: 300
                    else -> alertDistanceMeters
                }

                when {
                    distanceM <= nearAlertDistanceMeters -> fireAlert(AlertEvent(
                        type = AlertEvent.AlertType.SPEED_CAMERA_NEAR,
                        title = camera.category.alertTitle, message = camera.description,
                        distanceMeters = distanceM, latitude = camera.latitude,
                        longitude = camera.longitude, speedLimit = camera.speedLimit
                    ), camera.category)
                    distanceM <= effectiveAlertDistance -> fireAlert(AlertEvent(
                        type = AlertEvent.AlertType.SPEED_CAMERA_APPROACHING,
                        title = camera.category.alertTitle, message = camera.description,
                        distanceMeters = distanceM, latitude = camera.latitude,
                        longitude = camera.longitude, speedLimit = camera.speedLimit
                    ), camera.category)
                }

                if (camera.speedLimit > 0 &&
                    currentSpeedKmh > camera.speedLimit + getSpeedTolerance() &&
                    distanceM <= effectiveAlertDistance) {
                    fireAlert(AlertEvent(
                        type = AlertEvent.AlertType.OVER_SPEED_LIMIT,
                        title = "Velocita' superata",
                        message = "${currentSpeedKmh.toInt()} km/h, limite ${camera.speedLimit}",
                        distanceMeters = distanceM, latitude = camera.latitude,
                        longitude = camera.longitude, speedLimit = camera.speedLimit
                    ))
                }
            }
        }

        if (prefs.getBoolean("alerts_poi_enabled", true)) {
            val pois = dbHelper.getPoisInBoundingBox(
                location.latitude, location.longitude, searchRadiusMeters
            )
            pois.forEach { poi ->
                if (!isPoiCategoryAlertEnabled(poi.category)) return@forEach
                val poiLoc = Location("poi").apply {
                    latitude = poi.latitude; longitude = poi.longitude
                }
                val distanceM = location.distanceTo(poiLoc).toInt()
                val threshold = if (poi.alertDistance > 0) poi.alertDistance else alertDistanceMeters
                if (distanceM <= threshold) {
                    fireAlert(AlertEvent(
                        type = AlertEvent.AlertType.POI_APPROACHING,
                        title = "${poi.category.emoji} ${poi.name}", message = poi.description,
                        distanceMeters = distanceM, latitude = poi.latitude, longitude = poi.longitude
                    ))
                }
            }
        }
    }

    private suspend fun fireAlert(event: AlertEvent, category: SpeedCamera.CameraCategory? = null) = withContext(Dispatchers.Main) {
        alertManager.handleAlert(event, category)
        onAlert?.invoke(event)
    }

    private fun buildNotificationText(): String {
        val speedStr = "${currentSpeedKmh.toInt()} km/h"
        val weatherStr = currentWeather?.let { " · ${it.emoji} ${it.tempCelsius.toInt()}°C" } ?: ""
        return "$speedStr$weatherStr"
    }

    private fun isCategoryAlertEnabled(category: SpeedCamera.CameraCategory) =
        prefs.getBoolean(category.prefKey, true)
    private fun isPoiCategoryAlertEnabled(category: PointOfInterest.PoiCategory) =
        prefs.getBoolean(category.prefKey, true)
    private fun getCameraAlertTitle(camera: SpeedCamera) = camera.category.alertTitle
    private fun getSpeedTolerance() = prefs.getString("speed_tolerance", "5")?.toIntOrNull() ?: 5

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "NavAlert Navigazione", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Servizio di navigazione attivo"; setShowBadge(false) }
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, NavigationService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NavAlert attivo")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_navigation)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(R.drawable.ic_stop, "Stop", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        serviceScope.cancel()
        alertManager.destroy()
        weatherManager.destroy()
        dbHelper.close()
        super.onDestroy()
    }
}

package com.navAlert.model

data class PointOfInterest(
    val id: Long = 0,
    val longitude: Double,
    val latitude: Double,
    val name: String,
    val description: String = "",
    val category: PoiCategory,
    val alertDistance: Int = -1,
    val sourceFile: String = "",
    val enabled: Boolean = true
) {
    enum class PoiCategory(val label: String, val prefKey: String, val emoji: String) {
        GAS_STATION("Stazione di Servizio", "poi_gas", "⛽"),
        PARKING("Parcheggio", "poi_parking", "🅿️"),
        TOLL("Casello Autostradale", "poi_toll", "🛣️"),
        HOSPITAL("Ospedale", "poi_hospital", "🏥"),
        POLICE("Polizia / Carabinieri", "poi_police", "👮"),
        RESTAURANT("Ristorante / Area Sosta", "poi_restaurant", "🍽️"),
        SCHOOL("Scuola / Zona Scolastica", "poi_school", "🏫"),
        DANGER("Zona Pericolosa", "poi_danger", "⚠️"),
        PREFERRED_LANE("Corsia Preferenziale", "poi_preferred_lane", "🚌"),
        CUSTOM("Personalizzato", "poi_custom", "📍");

        companion object {
            fun fromDescription(desc: String): PoiCategory {
                return when {
                    desc.contains("Servizio", ignoreCase = true) || desc.contains("Benzina", ignoreCase = true) -> GAS_STATION
                    desc.contains("Parcheggio", ignoreCase = true) -> PARKING
                    desc.contains("Casello", ignoreCase = true) || desc.contains("Pedaggi", ignoreCase = true) -> TOLL
                    desc.contains("Ospedale", ignoreCase = true) || desc.contains("Pronto", ignoreCase = true) -> HOSPITAL
                    desc.contains("Polizia", ignoreCase = true) || desc.contains("Carabinieri", ignoreCase = true) -> POLICE
                    desc.contains("Scuola", ignoreCase = true) -> SCHOOL
                    desc.contains("Pericolo", ignoreCase = true) || desc.contains("Pericolosa", ignoreCase = true) -> DANGER
                    else -> CUSTOM
                }
            }
        }
    }
}

package com.navAlert.model

/**
 * Dati meteo correnti da OpenWeather API
 */
data class WeatherData(
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long = System.currentTimeMillis(),

    // Condizioni
    val conditionCode: Int,          // codice OpenWeather (200-900)
    val conditionMain: String,       // "Rain", "Snow", "Clear", ecc.
    val conditionDescription: String, // "pioggia moderata"

    // Temperatura
    val tempCelsius: Float,
    val feelsLikeCelsius: Float,

    // Vento
    val windSpeedKmh: Float,         // convertito da m/s
    val windGustKmh: Float,          // raffica
    val windDegrees: Int,            // direzione in gradi

    // Umidità & pressione
    val humidity: Int,               // %
    val pressureHPa: Int,

    // Visibilità
    val visibilityMeters: Int,       // max 10000

    // Precipitazioni
    val rain1hMm: Float = 0f,        // mm ultima ora
    val snow1hMm: Float = 0f,

    // Nome città
    val cityName: String = ""
) {
    /** Emoji rappresentativa della condizione */
    val emoji: String get() = when (conditionCode) {
        in 200..232 -> "⛈️"   // Temporale
        in 300..321 -> "🌦️"  // Pioggerella
        in 500..504 -> "🌧️"  // Pioggia
        511        -> "🌨️"  // Pioggia gelata
        in 520..531 -> "🌧️"  // Rovesci
        in 600..622 -> "❄️"  // Neve
        in 700..741 -> "🌫️"  // Nebbia/foschia
        762        -> "🌋"   // Cenere vulcanica
        771        -> "💨"   // Burrasca
        781        -> "🌪️"  // Tornado
        800        -> "☀️"   // Sereno
        801        -> "🌤️"  // Poco nuvoloso
        802        -> "⛅"   // Parzialmente nuvoloso
        in 803..804 -> "☁️"  // Nuvoloso
        else       -> "🌡️"
    }

    /** Direzione vento in testo */
    val windDirection: String get() = when ((windDegrees + 22) / 45 % 8) {
        0 -> "N"; 1 -> "NE"; 2 -> "E"; 3 -> "SE"
        4 -> "S"; 5 -> "SO"; 6 -> "O"; 7 -> "NO"
        else -> "—"
    }

    /** True se le condizioni richiedono un avviso durante la guida */
    val requiresAlert: Boolean get() = when {
        conditionCode in 200..232 -> true   // Temporale
        conditionCode in 511..531 -> false  // Pioggia forte controllata
        conditionCode in 600..622 -> true   // Neve
        conditionCode in 701..741 && visibilityMeters < 500 -> true  // Nebbia fitta
        windSpeedKmh > 60 -> true
        windGustKmh > 80 -> true
        conditionCode == 781 || conditionCode == 771 -> true
        else -> false
    }

    /** Messaggio di alert vocale per le condizioni pericolose */
    val alertMessage: String get() = buildString {
        when {
            conditionCode in 200..232 -> append("Attenzione, temporale in corso. ")
            conditionCode in 600..622 -> append("Attenzione, neve sulla strada. ")
            conditionCode in 701..741 && visibilityMeters < 200 -> append("Attenzione, nebbia fitta, visibilità molto ridotta. ")
            conditionCode in 701..741 && visibilityMeters < 500 -> append("Attenzione, nebbia, ridurre la velocità. ")
            conditionCode == 781 -> append("Attenzione, tornado segnalato! ")
        }
        if (windSpeedKmh > 60) append("Vento forte, ${windSpeedKmh.toInt()} chilometri orari. ")
        if (windGustKmh > 80) append("Raffiche a ${windGustKmh.toInt()} chilometri orari. ")
    }.trim()

    /** Formattazione breve per la UI */
    val shortSummary: String get() = "$emoji ${tempCelsius.toInt()}°C  💨${windSpeedKmh.toInt()} km/h"
}

/**
 * Previsione singola (ogni 3 ore, da /forecast)
 */
data class WeatherForecast(
    val timestamp: Long,
    val conditionCode: Int,
    val conditionDescription: String,
    val tempCelsius: Float,
    val windSpeedKmh: Float,
    val rain3hMm: Float = 0f,
    val snow3hMm: Float = 0f,
    val pop: Float = 0f          // probabilità precipitazioni 0..1
) {
    val emoji: String get() = WeatherData(
        0.0, 0.0, conditionCode = conditionCode, conditionMain = "",
        conditionDescription = "", tempCelsius = 0f, feelsLikeCelsius = 0f,
        windSpeedKmh = 0f, windGustKmh = 0f, windDegrees = 0,
        humidity = 0, pressureHPa = 0, visibilityMeters = 10000
    ).emoji

    val timeLabel: String get() {
        val sdf = java.text.SimpleDateFormat("HH:mm", java.util.Locale.ITALY)
        return sdf.format(java.util.Date(timestamp * 1000))
    }

    val dateLabel: String get() {
        val sdf = java.text.SimpleDateFormat("EEE dd/MM", java.util.Locale.ITALY)
        return sdf.format(java.util.Date(timestamp * 1000))
    }
}

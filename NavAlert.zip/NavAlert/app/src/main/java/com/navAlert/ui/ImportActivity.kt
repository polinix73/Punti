package com.navAlert.ui

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.navAlert.databinding.ActivityImportBinding
import com.navAlert.db.DatabaseHelper
import com.navAlert.util.CsvImporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityImportBinding
    private lateinit var dbHelper: DatabaseHelper

    private val csvPickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            importFiles(uris)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        dbHelper = DatabaseHelper(this)

        setupUI()
        refreshStats()
    }

    private fun setupUI() {
        binding.btnPickCsv.setOnClickListener {
            csvPickerLauncher.launch("text/*")
        }

        binding.btnDeleteAll.setOnClickListener {
            showDeleteConfirmation()
        }

        binding.switchReplaceExisting.isChecked = false
    }

    private fun importFiles(uris: List<Uri>) {
        val replace = binding.switchReplaceExisting.isChecked
        val forceType = when (binding.rgImportType.checkedRadioButtonId) {
            com.navAlert.R.id.rbAutovelox -> CsvImporter.ImportType.SPEED_CAMERA
            com.navAlert.R.id.rbPoi -> CsvImporter.ImportType.POI
            else -> CsvImporter.ImportType.AUTO_DETECT
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.tvImportLog.text = "Importazione in corso...\n"
        binding.btnPickCsv.isEnabled = false

        lifecycleScope.launch {
            val sb = StringBuilder()
            uris.forEach { uri ->
                try {
                    val result = CsvImporter.importFromUri(
                        this@ImportActivity, uri, dbHelper, forceType, replace
                    )
                    sb.appendLine("✅ ${result.fileName}")
                    sb.appendLine("   Importati: ${result.imported}")
                    if (result.skipped > 0) sb.appendLine("   Saltati: ${result.skipped}")
                    if (result.errors > 0) sb.appendLine("   Errori: ${result.errors}")
                    sb.appendLine()
                } catch (e: Exception) {
                    sb.appendLine("❌ Errore: ${e.message}")
                }
            }

            withContext(Dispatchers.Main) {
                binding.progressBar.visibility = View.GONE
                binding.tvImportLog.text = sb.toString()
                binding.btnPickCsv.isEnabled = true
                refreshStats()

                // Salva flag "database importato"
                getSharedPreferences("navAlert_prefs", MODE_PRIVATE)
                    .edit().putBoolean("db_imported", true).apply()
            }
        }
    }

    private fun refreshStats() {
        lifecycleScope.launch(Dispatchers.IO) {
            val totalCameras = dbHelper.getCameraCount()
            val totalPois = dbHelper.getPoiCount()
            val byCategory = dbHelper.getCameraCountByCategory()

            withContext(Dispatchers.Main) {
                binding.tvStatsCameras.text = "Autovelox nel DB: $totalCameras"
                binding.tvStatsPoi.text = "POI nel DB: $totalPois"

                val detail = byCategory.entries.joinToString("\n") { (cat, count) ->
                    "  • $cat: $count"
                }
                binding.tvStatsDetail.text = if (detail.isEmpty()) "Nessun dato" else detail
            }
        }
    }

    private fun showDeleteConfirmation() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Elimina tutti i dati")
            .setMessage("Sei sicuro di voler eliminare tutti gli autovelox dal database?")
            .setPositiveButton("Elimina") { _, _ ->
                dbHelper.deleteAllCameras()
                refreshStats()
                Toast.makeText(this, "Database svuotato", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onDestroy() {
        dbHelper.close()
        super.onDestroy()
    }
}

package com.navAlert.util

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.preference.PreferenceManager
import com.navAlert.model.AlertEvent
import com.navAlert.model.SpeedCamera
import java.util.Locale

/**
 * Gestisce l'intera catena audio degli alert:
 *  1. Suono originale della categoria (se disponibile negli assets)
 *  2. TTS con distanza + limite di velocità
 *
 * Modalità configurabili:
 *  - SOUND_THEN_TTS  → suono originale, poi voce con distanza
 *  - TTS_ONLY        → solo voce
 *  - SOUND_ONLY      → solo suono originale (no distanza vocale)
 *  - SILENT          → solo vibrazione
 */
class SoundManager(private val context: Context) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "SoundManager"

        /**
         * Mappa categoria → nome file audio in assets/sounds/
         * null = nessun suono originale, usa solo TTS
         */
        private val CATEGORY_SOUNDS = mapOf(
            SpeedCamera.CameraCategory.BLACK_POINT      to "Black_Points.ogg",
            SpeedCamera.CameraCategory.DISSUASORE       to "Dissuasori.mp3",
            SpeedCamera.CameraCategory.SICVE_START      to "Sicve_Inizio.ogg",
            SpeedCamera.CameraCategory.SICVE_END        to "Sicve_Fine.ogg",
            SpeedCamera.CameraCategory.SICVE_ALERT      to "Sicve_Avviso.ogg",
            SpeedCamera.CameraCategory.TUTOR_ROAD       to "Tutor_Strade_Statali.ogg",
            SpeedCamera.CameraCategory.PREFERRED_LANE   to "Corsie_Preferenziali.mp3"
            // FIXED, MOBILE, SEMI_PERMANENT, TUTOR, RED_LIGHT, SPEED_BUMP, SORPASSOMETRO
            // → nessun suono originale, solo TTS
        )

        // Frasi TTS complete per ogni categoria (lette DOPO il suono, se presente)
        private fun ttsPhrase(event: AlertEvent, withDistance: Boolean): String {
            val distStr = if (withDistance) formatDistance(event.distanceMeters) else ""
            val speedStr = if (event.speedLimit > 0) ", limite ${event.speedLimit}" else ""

            return when {
                event.title.contains("Dosso", ignoreCase = true) ->
                    if (withDistance) "Dosso tra $distStr" else "Dosso"

                event.title.contains("Dissuasore", ignoreCase = true) ->
                    if (withDistance) "Dissuasore tra $distStr" else "Dissuasore"

                event.title.contains("nero", ignoreCase = true) ||
                event.title.contains("pericolosa", ignoreCase = true) ->
                    "Zona pericolosa${if (withDistance) " tra $distStr" else ""}"

                event.title.contains("SICVE") || event.title.contains("Inizio") ->
                    "Inizio controllo velocita' media$speedStr"

                event.title.contains("Fine") ->
                    "Fine controllo velocita' media"

                event.title.contains("Avviso") || event.title.contains("corso") ->
                    "Controllo velocita' media in corso$speedStr"

                event.title.contains("Tutor", ignoreCase = true) ->
                    "Sistema Tutor${if (withDistance) " tra $distStr" else ""}$speedStr"

                event.title.contains("Semaforo", ignoreCase = true) ->
                    "Semaforo con autovelox${if (withDistance) " tra $distStr" else ""}$speedStr"

                event.title.contains("fisso", ignoreCase = true) ->
                    "Autovelox fisso${if (withDistance) " tra $distStr" else ""}$speedStr"

                event.title.contains("mobile", ignoreCase = true) ->
                    "Autovelox mobile${if (withDistance) " tra $distStr" else ""}$speedStr"

                event.title.contains("semipermanente", ignoreCase = true) ||
                event.title.contains("box", ignoreCase = true) ->
                    "Box semipermanente${if (withDistance) " tra $distStr" else ""}$speedStr"

                event.title.contains("Corsia", ignoreCase = true) ->
                    "Attenzione, corsia preferenziale${if (withDistance) " tra $distStr" else ""}"

                event.title.contains("sorpassometro", ignoreCase = true) ->
                    "Rilevatore sorpassi${if (withDistance) " tra $distStr" else ""}"

                event.type == AlertEvent.AlertType.OVER_SPEED_LIMIT ->
                    "Velocita' superata, rallentare$speedStr"

                else ->
                    "Attenzione${if (withDistance) " tra $distStr" else ""}$speedStr"
            }
        }

        private fun formatDistance(meters: Int): String = when {
            meters >= 1000 -> {
                val km = meters / 1000
                val frac = (meters % 1000) / 100
                if (frac == 0) "$km chilometri" else "$km.$frac chilometri"
            }
            else -> "$meters metri"
        }
    }

    // ---- Stato interno ----

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var mediaPlayer: MediaPlayer? = null
    private var pendingTtsAfterSound: String? = null

    private val prefs get() = PreferenceManager.getDefaultSharedPreferences(context)

    enum class AlertMode { SOUND_THEN_TTS, TTS_ONLY, SOUND_ONLY, SILENT }

    val alertMode: AlertMode
        get() = when (prefs.getString("alert_audio_mode", "SOUND_THEN_TTS")) {
            "TTS_ONLY"   -> AlertMode.TTS_ONLY
            "SOUND_ONLY" -> AlertMode.SOUND_ONLY
            "SILENT"     -> AlertMode.SILENT
            else         -> AlertMode.SOUND_THEN_TTS
        }

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.ITALIAN)
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                       result != TextToSpeech.LANG_NOT_SUPPORTED
            updateTtsParams()

            // Listener: quando il TTS finisce, non fare altro
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {}
                override fun onError(utteranceId: String?) {
                    Log.w(TAG, "TTS error: $utteranceId")
                }
            })
        }
    }

    // ---- API principale ----

    /**
     * Gestisce un alert: decide cosa riprodurre in base alla modalità e alla categoria.
     * @param categoryHint categoria dell'elemento (per scegliere il suono)
     */
    fun playAlert(
        event: AlertEvent,
        categoryHint: SpeedCamera.CameraCategory? = null
    ) {
        if (!prefs.getBoolean("alerts_enabled", true)) return

        val mode = alertMode
        if (mode == AlertMode.SILENT) return

        val soundFile = categoryHint?.let { CATEGORY_SOUNDS[it] }

        when (mode) {
            AlertMode.SOUND_THEN_TTS -> {
                if (soundFile != null) {
                    // Prima il suono, poi TTS con la distanza
                    val ttsText = buildTtsText(event, withDistance = true)
                    playSound(soundFile, onComplete = {
                        if (ttsReady && ttsText.isNotBlank()) speakNow(ttsText)
                    })
                } else {
                    // Nessun suono originale: solo TTS
                    val ttsText = buildTtsText(event, withDistance = true)
                    if (ttsReady && ttsText.isNotBlank()) speakNow(ttsText)
                }
            }
            AlertMode.TTS_ONLY -> {
                val ttsText = buildTtsText(event, withDistance = true)
                if (ttsReady && ttsText.isNotBlank()) speakNow(ttsText)
            }
            AlertMode.SOUND_ONLY -> {
                if (soundFile != null) playSound(soundFile)
                else {
                    // Fallback: TTS breve senza distanza
                    val ttsText = buildTtsText(event, withDistance = false)
                    if (ttsReady && ttsText.isNotBlank()) speakNow(ttsText)
                }
            }
            AlertMode.SILENT -> { /* già gestito sopra */ }
        }
    }

    /** Annuncio meteo pericoloso (solo TTS) */
    fun speakWeatherAlert(weather: com.navAlert.model.WeatherData) {
        if (!prefs.getBoolean("tts_enabled", true) || !ttsReady) return
        val msg = weather.alertMessage
        if (msg.isNotBlank()) speakNow(msg)
    }

    // ---- Riproduzione suono da assets ----

    private fun playSound(assetFileName: String, onComplete: (() -> Unit)? = null) {
        try {
            stopCurrentSound()
            val afd: AssetFileDescriptor = context.assets.openFd("sounds/$assetFileName")
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                val vol = prefs.getInt("tts_volume", 100) / 100f
                setVolume(vol, vol)
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setOnCompletionListener {
                    it.release()
                    mediaPlayer = null
                    onComplete?.invoke()
                }
                setOnErrorListener { _, _, _ ->
                    release()
                    mediaPlayer = null
                    onComplete?.invoke()
                    true
                }
                prepare()
                start()
            }
            mediaPlayer = mp
        } catch (e: Exception) {
            Log.e(TAG, "Errore riproduzione $assetFileName: ${e.message}")
            onComplete?.invoke()
        }
    }

    private fun stopCurrentSound() {
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (_: Exception) {}
        mediaPlayer = null
    }

    // ---- TTS ----

    private fun buildTtsText(event: AlertEvent, withDistance: Boolean): String =
        ttsPhrase(event, withDistance)

    private fun speakNow(text: String) {
        if (!ttsReady) return
        val vol = prefs.getInt("tts_volume", 100) / 100f
        val bundle = android.os.Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, vol)
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, bundle, "alert_${System.currentTimeMillis()}")
    }

    fun updateTtsParams() {
        val speed = prefs.getString("tts_speed_pref", "1.0")?.toFloatOrNull() ?: 1.0f
        tts?.setSpeechRate(speed)
        tts?.setPitch(1.0f)
    }

    fun stopAll() {
        tts?.stop()
        stopCurrentSound()
    }

    fun destroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        stopCurrentSound()
    }
}

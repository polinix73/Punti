package com.navAlert.util

import android.content.Context
import android.util.Log
import androidx.preference.PreferenceManager
import com.navAlert.model.WeatherData
import com.navAlert.model.WeatherForecast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class WeatherManager(private val context: Context) {

    companion object {
        private const val TAG = "WeatherManager"
        private const val API_KEY = "c29f0f51954e536593d8c011e805fcfb"
        private const val BASE_URL = "https://api.openweathermap.org/data/2.5"
        private const val UNITS = "metric"
        private const val LANG = "it"

        // Aggiorna meteo al massimo ogni X minuti (evita troppe chiamate API)
        private const val MIN_UPDATE_INTERVAL_MS = 5 * 60 * 1000L  // 5 minuti
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val prefs get() = PreferenceManager.getDefaultSharedPreferences(context)

    // Cache
    private var lastWeather: WeatherData? = null
    private var lastForecast: List<WeatherForecast> = emptyList()
    private var lastFetchTime = 0L
    private var lastFetchLat = 0.0
    private var lastFetchLon = 0.0

    // Callback
    var onWeatherUpdate: ((WeatherData) -> Unit)? = null
    var onForecastUpdate: ((List<WeatherForecast>) -> Unit)? = null
    var onWeatherAlert: ((WeatherData) -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    val cachedWeather: WeatherData? get() = lastWeather
    val cachedForecast: List<WeatherForecast> get() = lastForecast

    /** Controlla e aggiorna il meteo se necessario (chiamato dal NavigationService) */
    suspend fun updateIfNeeded(lat: Double, lon: Double) {
        if (!prefs.getBoolean("weather_enabled", true)) return

        val now = System.currentTimeMillis()
        val intervalMs = (prefs.getString("weather_update_interval", "10")?.toLongOrNull() ?: 10L) * 60_000L
        val effectiveInterval = maxOf(intervalMs, MIN_UPDATE_INTERVAL_MS)

        // Aggiorna se: troppo tempo passato OPPURE spostamento significativo (>2km)
        val distanceMoved = distanceKm(lat, lon, lastFetchLat, lastFetchLon)
        val timeExpired = (now - lastFetchTime) > effectiveInterval

        if (!timeExpired && distanceMoved < 2.0 && lastWeather != null) return

        fetchCurrentWeather(lat, lon)
        fetchForecast(lat, lon)
    }

    /** Fetch meteo corrente */
    suspend fun fetchCurrentWeather(lat: Double, lon: Double): WeatherData? = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/weather?lat=$lat&lon=$lon&appid=$API_KEY&units=$UNITS&lang=$LANG"
            val response = httpGet(url) ?: return@withContext null
            val weather = parseCurrentWeather(response, lat, lon)

            lastWeather = weather
            lastFetchTime = System.currentTimeMillis()
            lastFetchLat = lat
            lastFetchLon = lon

            withContext(Dispatchers.Main) {
                onWeatherUpdate?.invoke(weather)
                if (weather.requiresAlert && prefs.getBoolean("weather_alerts_enabled", true)) {
                    // Controlla se l'alert è già stato dato di recente
                    val lastAlertTime = prefs.getLong("last_weather_alert_time", 0L)
                    if (System.currentTimeMillis() - lastAlertTime > 10 * 60_000L) {
                        prefs.edit().putLong("last_weather_alert_time", System.currentTimeMillis()).apply()
                        onWeatherAlert?.invoke(weather)
                    }
                }
            }
            weather
        } catch (e: Exception) {
            Log.e(TAG, "Errore fetch meteo: ${e.message}")
            withContext(Dispatchers.Main) { onError?.invoke(e.message ?: "Errore meteo") }
            null
        }
    }

    /** Fetch previsioni (5 giorni, ogni 3 ore) */
    suspend fun fetchForecast(lat: Double, lon: Double): List<WeatherForecast> = withContext(Dispatchers.IO) {
        try {
            val url = "$BASE_URL/forecast?lat=$lat&lon=$lon&appid=$API_KEY&units=$UNITS&lang=$LANG&cnt=16"
            val response = httpGet(url) ?: return@withContext emptyList()
            val forecasts = parseForecast(response)

            lastForecast = forecasts
            withContext(Dispatchers.Main) { onForecastUpdate?.invoke(forecasts) }
            forecasts
        } catch (e: Exception) {
            Log.e(TAG, "Errore fetch previsioni: ${e.message}")
            emptyList()
        }
    }

    // ---- Parsing JSON ----

    private fun parseCurrentWeather(json: String, lat: Double, lon: Double): WeatherData {
        val root = JSONObject(json)
        val weather = root.getJSONArray("weather").getJSONObject(0)
        val main = root.getJSONObject("main")
        val wind = root.getJSONObject("wind")
        val visibility = root.optInt("visibility", 10000)
        val cityName = root.optString("name", "")

        val rain1h = root.optJSONObject("rain")?.optDouble("1h", 0.0)?.toFloat() ?: 0f
        val snow1h = root.optJSONObject("snow")?.optDouble("1h", 0.0)?.toFloat() ?: 0f

        val windSpeedMs = wind.optDouble("speed", 0.0)
        val windGustMs = wind.optDouble("gust", windSpeedMs)

        return WeatherData(
            latitude = lat,
            longitude = lon,
            conditionCode = weather.getInt("id"),
            conditionMain = weather.getString("main"),
            conditionDescription = weather.getString("description"),
            tempCelsius = main.getDouble("temp").toFloat(),
            feelsLikeCelsius = main.getDouble("feels_like").toFloat(),
            windSpeedKmh = (windSpeedMs * 3.6).toFloat(),
            windGustKmh = (windGustMs * 3.6).toFloat(),
            windDegrees = wind.optInt("deg", 0),
            humidity = main.getInt("humidity"),
            pressureHPa = main.getInt("pressure"),
            visibilityMeters = visibility,
            rain1hMm = rain1h,
            snow1hMm = snow1h,
            cityName = cityName
        )
    }

    private fun parseForecast(json: String): List<WeatherForecast> {
        val root = JSONObject(json)
        val list = root.getJSONArray("list")
        val result = mutableListOf<WeatherForecast>()

        for (i in 0 until list.length()) {
            val item = list.getJSONObject(i)
            val weather = item.getJSONArray("weather").getJSONObject(0)
            val main = item.getJSONObject("main")
            val wind = item.getJSONObject("wind")

            val rain3h = item.optJSONObject("rain")?.optDouble("3h", 0.0)?.toFloat() ?: 0f
            val snow3h = item.optJSONObject("snow")?.optDouble("3h", 0.0)?.toFloat() ?: 0f
            val pop = item.optDouble("pop", 0.0).toFloat()

            result.add(WeatherForecast(
                timestamp = item.getLong("dt"),
                conditionCode = weather.getInt("id"),
                conditionDescription = weather.getString("description"),
                tempCelsius = main.getDouble("temp").toFloat(),
                windSpeedKmh = (wind.optDouble("speed", 0.0) * 3.6).toFloat(),
                rain3hMm = rain3h,
                snow3hMm = snow3h,
                pop = pop
            ))
        }
        return result
    }

    private fun httpGet(url: String): String? {
        val request = Request.Builder().url(url).build()
        val response = httpClient.newCall(request).execute()
        return if (response.isSuccessful) response.body?.string() else null
    }

    private fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        if (lat2 == 0.0 && lon2 == 0.0) return Double.MAX_VALUE
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2).let { it * it } +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2).let { it * it }
        return 6371.0 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    }

    fun destroy() {
        httpClient.dispatcher.executorService.shutdown()
    }
}

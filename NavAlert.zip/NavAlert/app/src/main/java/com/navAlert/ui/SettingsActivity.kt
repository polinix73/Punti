package com.navAlert.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.*
import com.navAlert.R
import com.navAlert.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.title_settings)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, NavAlertSettingsFragment())
                .commit()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

class NavAlertSettingsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)

        // Collegamento dinamico per mostrare il valore corrente
        findPreference<SeekBarPreference>("tts_volume")?.apply {
            summary = "Volume voce: $value%"
            setOnPreferenceChangeListener { pref, newValue ->
                pref.summary = "Volume voce: $newValue%"
                true
            }
        }

        findPreference<ListPreference>("alert_distance")?.apply {
            summary = "Avvisa a: ${value}m"
            setOnPreferenceChangeListener { pref, newValue ->
                (pref as ListPreference).summary = "Avvisa a: ${newValue}m"
                true
            }
        }

        findPreference<ListPreference>("gps_interval")?.apply {
            summary = "Frequenza GPS: ${value}ms"
            setOnPreferenceChangeListener { pref, newValue ->
                (pref as ListPreference).summary = "Frequenza GPS: ${newValue}ms"
                true
            }
        }

        findPreference<EditTextPreference>("speed_tolerance")?.apply {
            summary = "Tolleranza velocità: +${text} km/h"
            setOnPreferenceChangeListener { pref, newValue ->
                pref.summary = "Tolleranza velocità: +${newValue} km/h"
                true
            }
        }

        findPreference<Preference>("btn_clear_cooldowns")?.setOnPreferenceClickListener {
            // Viene gestito dal servizio
            android.widget.Toast.makeText(context, "Alert riattivati", android.widget.Toast.LENGTH_SHORT).show()
            true
        }
    }
}

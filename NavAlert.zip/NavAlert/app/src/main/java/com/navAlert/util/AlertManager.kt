package com.navAlert.util

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.preference.PreferenceManager
import com.navAlert.model.AlertEvent
import com.navAlert.model.SpeedCamera

/**
 * Orchestratore alert:
 *  - Gestisce cooldown anti-ripetizione
 *  - Determina la categoria per SoundManager
 *  - Avvia suono/TTS e vibrazione
 */
class AlertManager(private val context: Context) {

    private val soundManager = SoundManager(context)
    private val prefs get() = PreferenceManager.getDefaultSharedPreferences(context)

    // cooldown: chiave = "lat_lon_type" → timestamp ultimo alert
    private val lastAlertMap = mutableMapOf<String, Long>()

    // Cooldown differenziato per tipo
    private fun cooldownMs(event: AlertEvent): Long = when (event.type) {
        AlertEvent.AlertType.SPEED_CAMERA_NEAR    -> 8_000L   //  8s - ravvicinato
        AlertEvent.AlertType.SPEED_CAMERA_APPROACHING -> 20_000L  // 20s - avvicinamento
        AlertEvent.AlertType.POI_APPROACHING      -> 30_000L  // 30s - POI
        AlertEvent.AlertType.OVER_SPEED_LIMIT     -> 10_000L  // 10s - velocità
    }

    fun handleAlert(event: AlertEvent, category: SpeedCamera.CameraCategory? = null) {
        if (!prefs.getBoolean("alerts_enabled", true)) return

        val key = "${event.latitude}_${event.longitude}_${event.type}"
        val now = System.currentTimeMillis()
        if (now - (lastAlertMap[key] ?: 0L) < cooldownMs(event)) return
        lastAlertMap[key] = now

        // Audio
        soundManager.playAlert(event, category)

        // Vibrazione
        if (prefs.getBoolean("vibration_enabled", true)) vibrate(event)
    }

    fun speakWeatherAlert(weather: com.navAlert.model.WeatherData) {
        soundManager.speakWeatherAlert(weather)
    }

    private fun vibrate(event: AlertEvent) {
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        val pattern: LongArray = when (event.type) {
            AlertEvent.AlertType.SPEED_CAMERA_NEAR      -> longArrayOf(0, 600, 100, 600)
            AlertEvent.AlertType.SPEED_CAMERA_APPROACHING -> longArrayOf(0, 250, 100, 250)
            AlertEvent.AlertType.POI_APPROACHING        -> longArrayOf(0, 120, 80, 120)
            AlertEvent.AlertType.OVER_SPEED_LIMIT       -> longArrayOf(0, 300, 100, 300, 100, 300)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }
    }

    fun clearCooldowns() = lastAlertMap.clear()

    fun destroy() {
        soundManager.destroy()
    }
}

package com.navAlert.model

data class SpeedCamera(
    val id: Long = 0,
    val longitude: Double,
    val latitude: Double,
    val description: String,
    val speedLimit: Int,
    val category: CameraCategory,
    val sourceFile: String = "",
    val enabled: Boolean = true
) {
    enum class CameraCategory(
        val label: String,
        val prefKey: String,
        val emoji: String,
        val alertTitle: String
    ) {
        // ---- Autovelox originali ----
        FIXED(
            "Autovelox Fisso", "cat_fixed", "📷",
            "Autovelox fisso"
        ),
        MOBILE(
            "Autovelox Mobile", "cat_mobile", "🚔",
            "Autovelox mobile"
        ),
        SEMI_PERMANENT(
            "Box Semipermanente", "cat_semi", "📦",
            "Box semipermanente"
        ),
        TUTOR(
            "Tutor Autostrade", "cat_tutor", "🛣️",
            "Sistema Tutor"
        ),
        RED_LIGHT(
            "Semaforo Rosso", "cat_redlight", "🚦",
            "Semaforo con autovelox"
        ),

        // ---- SICVE (velocità media) ----
        SICVE_START(
            "SICVE Inizio", "cat_sicve_start", "▶️",
            "Inizio controllo velocita' media"
        ),
        SICVE_END(
            "SICVE Fine", "cat_sicve_end", "⏹️",
            "Fine controllo velocita' media"
        ),
        SICVE_ALERT(
            "SICVE Avviso", "cat_sicve_alert", "⚠️",
            "Controllo velocita' media in corso"
        ),

        // ---- Tutor Strade Statali ----
        TUTOR_ROAD(
            "Tutor Strade Statali", "cat_tutor_road", "🛤️",
            "Sistema Tutor su strada statale"
        ),

        // ---- Ostacoli stradali ----
        SPEED_BUMP(
            "Dosso", "cat_dosso", "🔴",
            "Dosso"
        ),
        DISSUASORE(
            "Dissuasore", "cat_dissuasore", "🔶",
            "Dissuasore di velocita'"
        ),

        // ---- Pericoli e segnalazioni ----
        BLACK_POINT(
            "Punto Nero / Zona Pericolosa", "cat_black_point", "☠️",
            "Punto nero, zona pericolosa"
        ),
        SORPASSOMETRO(
            "Sorpassometro", "cat_sorpassometro", "🔁",
            "Rilevatore di sorpassi"
        ),
        PREFERRED_LANE(
            "Corsia Preferenziale", "cat_corsia_pref", "🚌",
            "Corsia preferenziale"
        ),

        OTHER(
            "Altro", "cat_other", "📍",
            "Rilevatore"
        );

        companion object {
            fun fromFileName(fileName: String): CameraCategory? = when {
                fileName.contains("Fissi", ignoreCase = true) ||
                fileName.contains("Autovelox_Fissi", ignoreCase = true) -> FIXED
                fileName.contains("Mobili", ignoreCase = true) -> MOBILE
                fileName.contains("Box_Semi", ignoreCase = true) -> SEMI_PERMANENT
                fileName.contains("Tutor_Strade", ignoreCase = true) -> TUTOR_ROAD
                fileName.contains("Tutor", ignoreCase = true) -> TUTOR
                fileName.contains("Semafori", ignoreCase = true) -> RED_LIGHT
                fileName.contains("Sicve_Inizio", ignoreCase = true) -> SICVE_START
                fileName.contains("Sicve_Fine", ignoreCase = true) -> SICVE_END
                fileName.contains("Sicve_Avviso", ignoreCase = true) -> SICVE_ALERT
                fileName.contains("Dossi", ignoreCase = true) -> SPEED_BUMP
                fileName.contains("Dissuasori", ignoreCase = true) -> DISSUASORE
                fileName.contains("Black_Points", ignoreCase = true) -> BLACK_POINT
                fileName.contains("Sorpassometri", ignoreCase = true) -> SORPASSOMETRO
                fileName.contains("Corsie_Preferenziali", ignoreCase = true) -> PREFERRED_LANE
                else -> null
            }

            fun fromDescription(desc: String): CameraCategory = when {
                desc.contains("Fisso", ignoreCase = true) -> FIXED
                desc.contains("Mobile", ignoreCase = true) ||
                desc.contains("Autobox", ignoreCase = true) -> MOBILE
                desc.contains("Box", ignoreCase = true) ||
                desc.contains("Semi", ignoreCase = true) -> SEMI_PERMANENT
                desc.contains("Tutor", ignoreCase = true) ||
                desc.contains("VERGILIUS", ignoreCase = true) -> TUTOR_ROAD
                desc.contains("ROSSOSTOP", ignoreCase = true) ||
                desc.contains("Semaforo", ignoreCase = true) -> RED_LIGHT
                desc.contains("INIZIO", ignoreCase = true) &&
                (desc.contains("SICVE", ignoreCase = true) || desc.contains("A", ignoreCase = false)) -> SICVE_START
                desc.contains("FINE", ignoreCase = true) -> SICVE_END
                desc.contains("AVVISO", ignoreCase = true) -> SICVE_ALERT
                desc.contains("DOSSO", ignoreCase = true) -> SPEED_BUMP
                desc.contains("DISSUASORE", ignoreCase = true) -> DISSUASORE
                desc.contains("ATT ", ignoreCase = true) ||
                desc.contains("Pericolosa", ignoreCase = true) ||
                desc.contains("Pericoloso", ignoreCase = true) -> BLACK_POINT
                else -> OTHER
            }
        }
    }
}

package com.navAlert.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.navAlert.model.PointOfInterest
import com.navAlert.model.SpeedCamera

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "navAlert.db"
        const val DATABASE_VERSION = 2

        // Tabella Autovelox
        const val TABLE_CAMERAS = "speed_cameras"
        const val COL_ID = "_id"
        const val COL_LON = "longitude"
        const val COL_LAT = "latitude"
        const val COL_DESC = "description"
        const val COL_SPEED_LIMIT = "speed_limit"
        const val COL_CATEGORY = "category"
        const val COL_SOURCE = "source_file"
        const val COL_ENABLED = "enabled"

        // Tabella POI
        const val TABLE_POI = "points_of_interest"
        const val COL_POI_NAME = "name"
        const val COL_POI_DESC = "description"
        const val COL_POI_CATEGORY = "category"
        const val COL_POI_ALERT_DIST = "alert_distance"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TABLE_CAMERAS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_LON REAL NOT NULL,
                $COL_LAT REAL NOT NULL,
                $COL_DESC TEXT,
                $COL_SPEED_LIMIT INTEGER DEFAULT 0,
                $COL_CATEGORY TEXT NOT NULL,
                $COL_SOURCE TEXT,
                $COL_ENABLED INTEGER DEFAULT 1
            )
        """.trimIndent())

        // Indice spaziale approssimativo (lat/lon)
        db.execSQL("CREATE INDEX idx_cameras_lat ON $TABLE_CAMERAS ($COL_LAT)")
        db.execSQL("CREATE INDEX idx_cameras_lon ON $TABLE_CAMERAS ($COL_LON)")
        db.execSQL("CREATE INDEX idx_cameras_cat ON $TABLE_CAMERAS ($COL_CATEGORY)")

        db.execSQL("""
            CREATE TABLE $TABLE_POI (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_LON REAL NOT NULL,
                $COL_LAT REAL NOT NULL,
                $COL_POI_NAME TEXT NOT NULL,
                $COL_POI_DESC TEXT,
                $COL_POI_CATEGORY TEXT NOT NULL,
                $COL_POI_ALERT_DIST INTEGER DEFAULT -1,
                $COL_ENABLED INTEGER DEFAULT 1
            )
        """.trimIndent())

        db.execSQL("CREATE INDEX idx_poi_lat ON $TABLE_POI ($COL_LAT)")
        db.execSQL("CREATE INDEX idx_poi_lon ON $TABLE_POI ($COL_LON)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CAMERAS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_POI")
        onCreate(db)
    }

    // ========== SPEED CAMERAS ==========

    fun insertCamera(camera: SpeedCamera): Long {
        val db = writableDatabase
        val cv = ContentValues().apply {
            put(COL_LON, camera.longitude)
            put(COL_LAT, camera.latitude)
            put(COL_DESC, camera.description)
            put(COL_SPEED_LIMIT, camera.speedLimit)
            put(COL_CATEGORY, camera.category.name)
            put(COL_SOURCE, camera.sourceFile)
            put(COL_ENABLED, if (camera.enabled) 1 else 0)
        }
        return db.insert(TABLE_CAMERAS, null, cv)
    }

    fun insertCamerasBatch(cameras: List<SpeedCamera>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            cameras.forEach { camera ->
                val cv = ContentValues().apply {
                    put(COL_LON, camera.longitude)
                    put(COL_LAT, camera.latitude)
                    put(COL_DESC, camera.description)
                    put(COL_SPEED_LIMIT, camera.speedLimit)
                    put(COL_CATEGORY, camera.category.name)
                    put(COL_SOURCE, camera.sourceFile)
                    put(COL_ENABLED, if (camera.enabled) 1 else 0)
                }
                db.insert(TABLE_CAMERAS, null, cv)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /**
     * Query ottimizzata: cerca solo nei punti dentro un bounding box
     * per poi fare il calcolo preciso di distanza in memoria.
     */
    fun getCamerasInBoundingBox(
        centerLat: Double,
        centerLon: Double,
        radiusMeters: Double,
        enabledCategoriesOnly: Boolean = true
    ): List<SpeedCamera> {
        val latDelta = radiusMeters / 111_320.0
        val lonDelta = radiusMeters / (111_320.0 * Math.cos(Math.toRadians(centerLat)))

        val minLat = centerLat - latDelta
        val maxLat = centerLat + latDelta
        val minLon = centerLon - lonDelta
        val maxLon = centerLon + lonDelta

        val enabledClause = if (enabledCategoriesOnly) "AND $COL_ENABLED = 1" else ""

        val cursor = readableDatabase.rawQuery("""
            SELECT * FROM $TABLE_CAMERAS
            WHERE $COL_LAT BETWEEN ? AND ?
              AND $COL_LON BETWEEN ? AND ?
              $enabledClause
        """.trimIndent(), arrayOf(
            minLat.toString(), maxLat.toString(),
            minLon.toString(), maxLon.toString()
        ))

        val result = mutableListOf<SpeedCamera>()
        cursor.use {
            while (it.moveToNext()) {
                result.add(cursorToCamera(it))
            }
        }
        return result
    }

    fun getCameraCount(): Int {
        val cursor = readableDatabase.rawQuery("SELECT COUNT(*) FROM $TABLE_CAMERAS", null)
        cursor.use {
            it.moveToFirst()
            return it.getInt(0)
        }
    }

    fun getCameraCountByCategory(): Map<String, Int> {
        val result = mutableMapOf<String, Int>()
        val cursor = readableDatabase.rawQuery(
            "SELECT $COL_CATEGORY, COUNT(*) FROM $TABLE_CAMERAS GROUP BY $COL_CATEGORY", null)
        cursor.use {
            while (it.moveToNext()) {
                result[it.getString(0)] = it.getInt(1)
            }
        }
        return result
    }

    fun setCategoryEnabled(category: SpeedCamera.CameraCategory, enabled: Boolean) {
        val cv = ContentValues().apply { put(COL_ENABLED, if (enabled) 1 else 0) }
        writableDatabase.update(TABLE_CAMERAS, cv, "$COL_CATEGORY = ?", arrayOf(category.name))
    }

    fun deleteAllCameras() {
        writableDatabase.delete(TABLE_CAMERAS, null, null)
    }

    fun deleteCamerasBySource(sourceFile: String) {
        writableDatabase.delete(TABLE_CAMERAS, "$COL_SOURCE = ?", arrayOf(sourceFile))
    }

    private fun cursorToCamera(cursor: android.database.Cursor): SpeedCamera {
        val category = try {
            SpeedCamera.CameraCategory.valueOf(cursor.getString(cursor.getColumnIndexOrThrow(COL_CATEGORY)))
        } catch (e: Exception) {
            SpeedCamera.CameraCategory.OTHER
        }
        return SpeedCamera(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ID)),
            longitude = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_LON)),
            latitude = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_LAT)),
            description = cursor.getString(cursor.getColumnIndexOrThrow(COL_DESC)) ?: "",
            speedLimit = cursor.getInt(cursor.getColumnIndexOrThrow(COL_SPEED_LIMIT)),
            category = category,
            sourceFile = cursor.getString(cursor.getColumnIndexOrThrow(COL_SOURCE)) ?: "",
            enabled = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ENABLED)) == 1
        )
    }

    // ========== POINTS OF INTEREST ==========

    fun insertPoi(poi: PointOfInterest): Long {
        val cv = ContentValues().apply {
            put(COL_LON, poi.longitude)
            put(COL_LAT, poi.latitude)
            put(COL_POI_NAME, poi.name)
            put(COL_POI_DESC, poi.description)
            put(COL_POI_CATEGORY, poi.category.name)
            put(COL_POI_ALERT_DIST, poi.alertDistance)
            put(COL_ENABLED, if (poi.enabled) 1 else 0)
        }
        return writableDatabase.insert(TABLE_POI, null, cv)
    }

    fun insertPoisBatch(pois: List<PointOfInterest>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            pois.forEach { poi ->
                val cv = ContentValues().apply {
                    put(COL_LON, poi.longitude)
                    put(COL_LAT, poi.latitude)
                    put(COL_POI_NAME, poi.name)
                    put(COL_POI_DESC, poi.description)
                    put(COL_POI_CATEGORY, poi.category.name)
                    put(COL_POI_ALERT_DIST, poi.alertDistance)
                    put(COL_ENABLED, if (poi.enabled) 1 else 0)
                }
                db.insert(TABLE_POI, null, cv)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun getPoisInBoundingBox(
        centerLat: Double,
        centerLon: Double,
        radiusMeters: Double
    ): List<PointOfInterest> {
        val latDelta = radiusMeters / 111_320.0
        val lonDelta = radiusMeters / (111_320.0 * Math.cos(Math.toRadians(centerLat)))

        val cursor = readableDatabase.rawQuery("""
            SELECT * FROM $TABLE_POI
            WHERE $COL_LAT BETWEEN ? AND ?
              AND $COL_LON BETWEEN ? AND ?
              AND $COL_ENABLED = 1
        """.trimIndent(), arrayOf(
            (centerLat - latDelta).toString(), (centerLat + latDelta).toString(),
            (centerLon - lonDelta).toString(), (centerLon + lonDelta).toString()
        ))

        val result = mutableListOf<PointOfInterest>()
        cursor.use {
            while (it.moveToNext()) result.add(cursorToPoi(it))
        }
        return result
    }

    fun getAllPois(): List<PointOfInterest> {
        val cursor = readableDatabase.rawQuery("SELECT * FROM $TABLE_POI ORDER BY $COL_POI_NAME", null)
        val result = mutableListOf<PointOfInterest>()
        cursor.use {
            while (it.moveToNext()) result.add(cursorToPoi(it))
        }
        return result
    }

    fun updatePoi(poi: PointOfInterest): Int {
        val cv = ContentValues().apply {
            put(COL_POI_NAME, poi.name)
            put(COL_POI_DESC, poi.description)
            put(COL_POI_CATEGORY, poi.category.name)
            put(COL_POI_ALERT_DIST, poi.alertDistance)
            put(COL_ENABLED, if (poi.enabled) 1 else 0)
        }
        return writableDatabase.update(TABLE_POI, cv, "$COL_ID = ?", arrayOf(poi.id.toString()))
    }

    fun deletePoi(id: Long): Int {
        return writableDatabase.delete(TABLE_POI, "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun getPoiCount(): Int {
        val cursor = readableDatabase.rawQuery("SELECT COUNT(*) FROM $TABLE_POI", null)
        cursor.use { it.moveToFirst(); return it.getInt(0) }
    }

    private fun cursorToPoi(cursor: android.database.Cursor): PointOfInterest {
        val category = try {
            PointOfInterest.PoiCategory.valueOf(cursor.getString(cursor.getColumnIndexOrThrow(COL_POI_CATEGORY)))
        } catch (e: Exception) {
            PointOfInterest.PoiCategory.CUSTOM
        }
        return PointOfInterest(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ID)),
            longitude = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_LON)),
            latitude = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_LAT)),
            name = cursor.getString(cursor.getColumnIndexOrThrow(COL_POI_NAME)) ?: "",
            description = cursor.getString(cursor.getColumnIndexOrThrow(COL_POI_DESC)) ?: "",
            category = category,
            alertDistance = cursor.getInt(cursor.getColumnIndexOrThrow(COL_POI_ALERT_DIST)),
            enabled = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ENABLED)) == 1
        )
    }
}

package com.navAlert.ui

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.navAlert.R
import com.navAlert.databinding.ActivityMainBinding
import com.navAlert.db.DatabaseHelper
import com.navAlert.model.AlertEvent
import com.navAlert.model.SpeedCamera
import com.navAlert.model.WeatherData
import com.navAlert.service.NavigationService
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityMainBinding
    private lateinit var dbHelper: DatabaseHelper

    private var googleMap: GoogleMap? = null
    private var navigationService: NavigationService? = null
    private var serviceBound = false
    private var isFollowingLocation = true
    private val cameraMarkers = mutableListOf<Marker>()
    private val poiMarkers = mutableListOf<Marker>()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as NavigationService.LocalBinder
            navigationService = binder.getService()
            serviceBound = true
            navigationService?.onLocationUpdate = { location, speedKmh -> updateLocationUI(location, speedKmh) }
            navigationService?.onAlert = { event -> showAlert(event) }
            navigationService?.onWeatherUpdate = { weather -> updateWeatherUI(weather) }
            // Mostra meteo già in cache se disponibile
            navigationService?.currentWeather?.let { updateWeatherUI(it) }
            updateNavButton()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            navigationService = null; serviceBound = false; updateNavButton()
        }
    }

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            enableMapLocation(); startNavigationService()
        } else {
            Toast.makeText(this, "Permesso GPS necessario", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        dbHelper = DatabaseHelper(this)
        setupMap()
        setupButtons()
        checkFirstRun()
    }

    private fun setupMap() {
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun setupButtons() {
        binding.fabNavigation.setOnClickListener {
            if (navigationService?.isNavigating() == true) stopNavigation()
            else requestLocationPermissionAndStart()
        }
        binding.fabCenter.setOnClickListener {
            isFollowingLocation = true
            navigationService?.lastLocation?.let { loc ->
                googleMap?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(loc.latitude, loc.longitude), 16f))
            }
        }
        binding.fabLayers.setOnClickListener { showLayerSelector() }
        binding.cardAlert.setOnClickListener { binding.cardAlert.visibility = View.GONE }

        // Click sul widget meteo -> apri schermata previsioni
        binding.cardWeather.setOnClickListener {
            startActivity(Intent(this, WeatherActivity::class.java))
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        map.uiSettings.apply {
            isZoomControlsEnabled = true; isCompassEnabled = true; isMapToolbarEnabled = false
        }
        map.setOnCameraMoveStartedListener { reason ->
            if (reason == GoogleMap.OnCameraMoveStartedReason.GESTURE) isFollowingLocation = false
        }
        map.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style_night))
        loadMarkersOnMap()
    }

    private fun loadMarkersOnMap() {
        lifecycleScope.launch(Dispatchers.IO) {
            val cameras = dbHelper.getCamerasInBoundingBox(42.0, 12.5, 50_000.0)
            val pois = dbHelper.getAllPois()
            withContext(Dispatchers.Main) {
                cameraMarkers.forEach { it.remove() }; cameraMarkers.clear()
                cameras.take(500).forEach { camera ->
                    googleMap?.addMarker(MarkerOptions()
                        .position(LatLng(camera.latitude, camera.longitude))
                        .title("${camera.description} - ${camera.speedLimit} km/h")
                        .icon(getCameraIcon(camera.category))
                        .anchor(0.5f, 0.5f)
                    )?.let { cameraMarkers.add(it) }
                }
                pois.forEach { poi ->
                    googleMap?.addMarker(MarkerOptions()
                        .position(LatLng(poi.latitude, poi.longitude))
                        .title("${poi.category.emoji} ${poi.name}")
                        .snippet(poi.description)
                    )?.let { poiMarkers.add(it) }
                }
            }
        }
    }

    private fun getCameraIcon(category: SpeedCamera.CameraCategory): BitmapDescriptor =
        when (category) {
            SpeedCamera.CameraCategory.FIXED ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)
            SpeedCamera.CameraCategory.MOBILE ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)
            SpeedCamera.CameraCategory.SEMI_PERMANENT ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)
            SpeedCamera.CameraCategory.TUTOR,
            SpeedCamera.CameraCategory.TUTOR_ROAD ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)
            SpeedCamera.CameraCategory.RED_LIGHT ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ROSE)
            SpeedCamera.CameraCategory.SICVE_START ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)
            SpeedCamera.CameraCategory.SICVE_END ->
                BitmapDescriptorFactory.defaultMarker(150f) // verde acqua
            SpeedCamera.CameraCategory.SICVE_ALERT ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)
            SpeedCamera.CameraCategory.SPEED_BUMP ->
                BitmapDescriptorFactory.defaultMarker(30f)  // arancione scuro
            SpeedCamera.CameraCategory.DISSUASORE ->
                BitmapDescriptorFactory.defaultMarker(20f)  // arancione chiaro
            SpeedCamera.CameraCategory.BLACK_POINT ->
                BitmapDescriptorFactory.defaultMarker(0f)   // rosso scuro
            SpeedCamera.CameraCategory.SORPASSOMETRO ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA)
            SpeedCamera.CameraCategory.PREFERRED_LANE ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)
            SpeedCamera.CameraCategory.OTHER ->
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN)
        }

    private fun updateLocationUI(location: Location, speedKmh: Float) {
        binding.tvSpeed.text = "${speedKmh.toInt()}"
        if (isFollowingLocation) {
            googleMap?.animateCamera(CameraUpdateFactory.newLatLng(LatLng(location.latitude, location.longitude)))
        }
        googleMap?.isMyLocationEnabled = true
    }

    private fun updateWeatherUI(weather: WeatherData) {
        binding.cardWeather.visibility = View.VISIBLE
        binding.tvWeatherEmoji.text = weather.emoji
        binding.tvWeatherTemp.text = "${weather.tempCelsius.toInt()}°C"
        binding.tvWeatherWind.text = "💨 ${weather.windSpeedKmh.toInt()} km/h"
        binding.tvWeatherHumidity.text = "💧${weather.humidity}%"
        binding.tvWeatherDesc.text = weather.conditionDescription.replaceFirstChar { it.uppercase() }
        binding.tvWeatherCity.text = weather.cityName

        // Visibilità ridotta -> tinta arancione sulla card
        if (weather.visibilityMeters < 1000 || weather.requiresAlert) {
            binding.cardWeather.setCardBackgroundColor(Color.parseColor("#BF37474E"))
        } else {
            binding.cardWeather.setCardBackgroundColor(Color.parseColor("#BF1A237E"))
        }
    }

    private fun showAlert(event: AlertEvent) {
        binding.cardAlert.visibility = View.VISIBLE
        binding.tvAlertTitle.text = event.title
        binding.tvAlertMessage.text = "${event.distanceMeters}m"
        val bgColor = when (event.type) {
            AlertEvent.AlertType.SPEED_CAMERA_NEAR -> Color.RED
            AlertEvent.AlertType.SPEED_CAMERA_APPROACHING -> Color.parseColor("#FF6B00")
            AlertEvent.AlertType.OVER_SPEED_LIMIT -> Color.parseColor("#CC0000")
            AlertEvent.AlertType.POI_APPROACHING -> Color.parseColor("#1565C0")
        }
        binding.cardAlert.setCardBackgroundColor(bgColor)
        binding.cardAlert.postDelayed({ binding.cardAlert.visibility = View.GONE }, 5000)
    }

    private fun requestLocationPermissionAndStart() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)

        if (permissions.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            enableMapLocation(); startNavigationService()
        } else {
            locationPermissionLauncher.launch(permissions.toTypedArray())
        }
    }

    private fun startNavigationService() {
        val intent = Intent(this, NavigationService::class.java).apply { action = NavigationService.ACTION_START }
        ContextCompat.startForegroundService(this, intent)
        bindService(Intent(this, NavigationService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
        updateNavButton()
    }

    private fun stopNavigation() {
        navigationService?.stopNavigation()
        if (serviceBound) { unbindService(serviceConnection); serviceBound = false }
        updateNavButton()
    }

    private fun enableMapLocation() {
        try { googleMap?.isMyLocationEnabled = true; googleMap?.uiSettings?.isMyLocationButtonEnabled = false }
        catch (e: SecurityException) {}
    }

    private fun updateNavButton() {
        val isNav = navigationService?.isNavigating() == true
        binding.fabNavigation.setImageResource(if (isNav) R.drawable.ic_stop else R.drawable.ic_navigation)
        binding.fabNavigation.backgroundTintList = ContextCompat.getColorStateList(
            this, if (isNav) R.color.nav_active else R.color.nav_inactive
        )
        binding.tvNavStatus.text = if (isNav) "Navigazione attiva" else "Premi per avviare"
    }

    private fun showLayerSelector() {
        val options = arrayOf(
            "📷 Autovelox Fissi", "🚔 Autovelox Mobili", "📦 Box Semipermanenti",
            "🚦 Semafori", "🛣️ Tutor Autostrade", "🛤️ Tutor Statali",
            "▶️ SICVE Inizio", "⏹️ SICVE Fine", "⚠️ SICVE Avviso",
            "🔴 Dossi", "🔶 Dissuasori", "☠️ Punti Neri",
            "🔁 Sorpassometri", "🚌 Corsie Preferenziali", "📍 POI"
        )
        val checked = BooleanArray(options.size) { true }
        val categories = SpeedCamera.CameraCategory.values().take(14)

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Livelli mappa visibili")
            .setMultiChoiceItems(options, checked) { _, which, isChecked ->
                if (which == options.size - 1) {
                    poiMarkers.forEach { it.isVisible = isChecked }
                } else {
                    val cat = categories.getOrNull(which) ?: return@setMultiChoiceItems
                    cameraMarkers.forEach { m ->
                        if (m.snippet == cat.name) m.isVisible = isChecked
                    }
                }
            }
            .setPositiveButton("OK", null).show()
    }

    private fun checkFirstRun() {
        val prefs = getSharedPreferences("navAlert_prefs", MODE_PRIVATE)
        if (!prefs.getBoolean("db_imported", false)) {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Benvenuto in NavAlert!")
                .setMessage("Nessun dato autovelox trovato.\nVuoi importare i file CSV?")
                .setPositiveButton("Importa ora") { _, _ -> startActivity(Intent(this, ImportActivity::class.java)) }
                .setNegativeButton("Dopo", null).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu); return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.menu_import -> { startActivity(Intent(this, ImportActivity::class.java)); true }
        R.id.menu_poi -> { startActivity(Intent(this, PoiManagerActivity::class.java)); true }
        R.id.menu_weather -> { startActivity(Intent(this, WeatherActivity::class.java)); true }
        R.id.menu_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
        else -> super.onOptionsItemSelected(item)
    }

    override fun onStart() {
        super.onStart()
        if (!serviceBound) bindService(Intent(this, NavigationService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
    }

    override fun onStop() {
        super.onStop()
        if (serviceBound && navigationService?.isNavigating() != true) { unbindService(serviceConnection); serviceBound = false }
    }

    override fun onDestroy() { dbHelper.close(); super.onDestroy() }
}

package com.navAlert.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.navAlert.R
import com.navAlert.db.DatabaseHelper
import com.navAlert.model.PointOfInterest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PoiManagerActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PoiAdapter
    private val pois = mutableListOf<PointOfInterest>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_poi_manager)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        dbHelper = DatabaseHelper(this)
        recyclerView = findViewById(R.id.recyclerPoi)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = PoiAdapter(pois,
            onEdit = { poi -> showEditPoiDialog(poi) },
            onDelete = { poi ->
                dbHelper.deletePoi(poi.id)
                loadPois()
            }
        )
        recyclerView.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fabAddPoi).setOnClickListener {
            showAddPoiDialog()
        }

        loadPois()
    }

    private fun loadPois() {
        lifecycleScope.launch(Dispatchers.IO) {
            val data = dbHelper.getAllPois()
            withContext(Dispatchers.Main) {
                pois.clear()
                pois.addAll(data)
                adapter.notifyDataSetChanged()
            }
        }
    }

    private fun showAddPoiDialog() {
        showPoiDialog(null) { name, desc, lat, lon, category, alertDist ->
            val poi = PointOfInterest(
                name = name, description = desc,
                latitude = lat, longitude = lon,
                category = category, alertDistance = alertDist
            )
            dbHelper.insertPoi(poi)
            loadPois()
        }
    }

    private fun showEditPoiDialog(poi: PointOfInterest) {
        showPoiDialog(poi) { name, desc, lat, lon, category, alertDist ->
            val updated = poi.copy(
                name = name, description = desc,
                latitude = lat, longitude = lon,
                category = category, alertDistance = alertDist
            )
            dbHelper.updatePoi(updated)
            loadPois()
        }
    }

    private fun showPoiDialog(
        existing: PointOfInterest?,
        onConfirm: (String, String, Double, Double, PointOfInterest.PoiCategory, Int) -> Unit
    ) {
        val view = layoutInflater.inflate(R.layout.dialog_poi_edit, null)
        val etName = view.findViewById<EditText>(R.id.etPoiName)
        val etDesc = view.findViewById<EditText>(R.id.etPoiDesc)
        val etLat = view.findViewById<EditText>(R.id.etPoiLat)
        val etLon = view.findViewById<EditText>(R.id.etPoiLon)
        val etAlertDist = view.findViewById<EditText>(R.id.etPoiAlertDist)
        val spinnerCategory = view.findViewById<Spinner>(R.id.spinnerPoiCategory)

        val categories = PointOfInterest.PoiCategory.values()
        spinnerCategory.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            categories.map { "${it.emoji} ${it.label}" }
        )

        existing?.let {
            etName.setText(it.name)
            etDesc.setText(it.description)
            etLat.setText(it.latitude.toString())
            etLon.setText(it.longitude.toString())
            etAlertDist.setText(if (it.alertDistance > 0) it.alertDistance.toString() else "")
            spinnerCategory.setSelection(categories.indexOf(it.category))
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Aggiungi POI" else "Modifica POI")
            .setView(view)
            .setPositiveButton("Salva") { _, _ ->
                val name = etName.text.toString().trim()
                val desc = etDesc.text.toString().trim()
                val lat = etLat.text.toString().toDoubleOrNull() ?: return@setPositiveButton
                val lon = etLon.text.toString().toDoubleOrNull() ?: return@setPositiveButton
                val alertDist = etAlertDist.text.toString().toIntOrNull() ?: -1
                val category = categories[spinnerCategory.selectedItemPosition]

                if (name.isNotEmpty()) {
                    onConfirm(name, desc, lat, lon, category, alertDist)
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onDestroy() {
        dbHelper.close()
        super.onDestroy()
    }
}

class PoiAdapter(
    private val pois: List<PointOfInterest>,
    private val onEdit: (PointOfInterest) -> Unit,
    private val onDelete: (PointOfInterest) -> Unit
) : RecyclerView.Adapter<PoiAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvPoiName)
        val tvCategory: TextView = view.findViewById(R.id.tvPoiCategory)
        val tvCoords: TextView = view.findViewById(R.id.tvPoiCoords)
        val btnEdit: ImageButton = view.findViewById(R.id.btnEditPoi)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDeletePoi)
        val switchEnabled: Switch = view.findViewById(R.id.switchPoiEnabled)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_poi, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val poi = pois[position]
        holder.tvName.text = "${poi.category.emoji} ${poi.name}"
        holder.tvCategory.text = poi.category.label
        holder.tvCoords.text = "%.5f, %.5f".format(poi.latitude, poi.longitude)
        holder.switchEnabled.isChecked = poi.enabled
        holder.btnEdit.setOnClickListener { onEdit(poi) }
        holder.btnDelete.setOnClickListener { onDelete(poi) }
    }

    override fun getItemCount() = pois.size
}

# NavAlert - App di Navigazione con Avvisi Autovelox

## Struttura del Progetto

```
NavAlert/
├── app/src/main/
│   ├── java/com/navAlert/
│   │   ├── model/
│   │   │   ├── SpeedCamera.kt       # Modello autovelox con categorie
│   │   │   ├── PointOfInterest.kt   # Modello POI con categorie
│   │   │   └── AlertEvent.kt        # Evento di avviso
│   │   ├── db/
│   │   │   └── DatabaseHelper.kt    # SQLite + query bounding box ottimizzate
│   │   ├── service/
│   │   │   └── NavigationService.kt # Servizio foreground GPS + rilevamento
│   │   ├── util/
│   │   │   ├── CsvImporter.kt       # Parser CSV lon,lat,desc@speed
│   │   │   └── AlertManager.kt      # TTS italiano + vibrazione
│   │   └── ui/
│   │       ├── MainActivity.kt      # Mappa + controlli
│   │       ├── ImportActivity.kt    # Import CSV
│   │       ├── SettingsActivity.kt  # Preferenze complete
│   │       └── PoiManagerActivity.kt # CRUD POI
│   ├── assets/autovelox/            # 13 CSV pre-caricati
│   └── res/
│       ├── xml/preferences.xml      # ~30 impostazioni configurabili
│       └── raw/map_style_night.json # Stile mappa notturna
```

---

## Setup in Android Studio

### 1. Clona / Apri il progetto
Apri la cartella `NavAlert/` come progetto in Android Studio Hedgehog o superiore.

### 2. Inserisci la tua Google Maps API Key

In `app/src/main/AndroidManifest.xml`, sostituisci:
```xml
android:value="YOUR_GOOGLE_MAPS_API_KEY"
```
con la tua chiave ottenuta da [Google Cloud Console](https://console.cloud.google.com).

Abilita queste API nel tuo progetto Google Cloud:
- Maps SDK for Android
- (opzionale) Directions API per navigazione turn-by-turn

### 3. Build e installa
```bash
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## Importazione dati autovelox

### Opzione A - Inclusi nell'app (automatico)
I 13 file CSV della cartella `assets/autovelox/` vengono importati al primo avvio tramite `CsvImporter.importFromAssets()`.

Chiama da `MainActivity.onCreate()`:
```kotlin
lifecycleScope.launch {
    CsvImporter.importFromAssets(this@MainActivity, dbHelper)
}
```

### Opzione B - Import manuale da file
Menu → **Importa CSV** → seleziona uno o più file dal dispositivo.

### Formato CSV supportato
```
longitudine,latitudine,Descrizione@LimiteVelocità
6.79366,44.95386,Autovelox Fisso@50
10.489990,43.423110,Autovelox Fisso@130
```

---

## Categorie riconosciute automaticamente

### Autovelox
| File/Categoria | Descrizione |
|---|---|
| `Autovelox_Fissi.csv` | Fissi generici |
| `Fissi30.csv` - `Fissi130.csv` | Fissi per limite specifico |
| `Autovelox_Mobili.csv` | Postazioni mobili |
| `Box_Semipermanenti.csv` | Box semipermanenti |

### POI (formato uguale, senza @velocità)
- Stazioni servizio, Parcheggi, Caselli, Ospedali, Polizia, Scuole, Zone pericolose, Personalizzati

---

## Configurazione (Impostazioni → ~30 opzioni)

| Categoria | Opzioni |
|---|---|
| **Alert generali** | On/off, distanza (100-1000m), tolleranza velocità |
| **Voce TTS** | On/off, volume, velocità parlato, italiano |
| **Vibrazione** | On/off con pattern diversi per tipo |
| **Categorie autovelox** | Toggle per ogni tipo (fisso, mobile, semi, tutor, rosso) |
| **Categorie POI** | Toggle per ogni categoria |
| **GPS** | Frequenza (500ms-5s), distanza minima |
| **Mappa** | Tipo (normale/satellite/ibrida), tema notte, layer visibili |

---

## Architettura tecnica

- **Foreground Service** con notifica persistente (evita kill del SO)
- **Bounding box query** su SQLite con indici lat/lon (query <10ms su 20k record)
- **Cooldown anti-ripetizione** alert (15 secondi per coordinate)
- **TTS Android** in italiano con coda messaggi
- **Google Maps** con stile notturno e marker colorati per categoria
- **Coroutines** per I/O non bloccante sulla UI

---

## Aggiunta di nuovi POI da codice
```kotlin
val dbHelper = DatabaseHelper(context)
dbHelper.insertPoi(PointOfInterest(
    longitude = 12.4922,
    latitude = 41.8902,
    name = "Colosseo",
    description = "Zona turistica, traffico intenso",
    category = PointOfInterest.PoiCategory.DANGER,
    alertDistance = 500  // avvisa a 500m, -1 = usa default settings
))
```

---

## Dipendenze principali
- Google Maps SDK for Android `18.2.0`
- Google Location Services `21.1.0`
- AndroidX Preference `1.2.1`
- Kotlinx Coroutines `1.7.3`
- Material Components `1.11.0`
